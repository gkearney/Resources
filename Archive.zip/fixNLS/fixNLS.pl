#!/usr/bin/perl

# This script takes as an argument a space seperated list of dirctory paths containing NLS DAISY/NIOS 2002 books. It will then edit the .opf .ncx and .smil files of those books to replace references to .3gp/3gpp audio with mp3 audio references. It will then convert the 3gp audio files first to WAV and then to mp3 using the NLS decoder and lame and will delete the original 3gp and temporary WAV audio files. WORK ONLY ON COPIES NEVER THE ORIGINALS!

# Gregory Kearney
# Manager - Accessible Media
# Association for the Blind of Western Australia
# 61 Kitchener Avenue, PO Box 101
# Victoria Park 6979, WA Australia
#
# Telephone: +61 (08) 9311 8246
# Telephone: +1 (307) 224 4022 (North America)
# Fax: +61 (08) 9361 8696
# Toll free: 1800 658 388 (Australia only)
# Email: gkearney@gmail.com 

# required Perl Modules
use Cwd; # module for finding the current working directory
use File::Basename;
use POSIX qw/strftime/;

# end of module list

#paths to the decoder program and lame change as needed.
$decoder = "C:\WINDOWS\decoder";
$lame = "C:\WINDOWS\lame";


my( $arg ); #the arguments a space seperated list of directories
my( $count ); #the count of directories
$count = 0; 

# For each directory path print the count the directory name and then call the ScanDirectory subroutine
foreach $arg ( @ARGV ) {
        $count++;
        print("Directory $count is '$arg'.\n" );
		$mypath = $arg;
		&ScanDirectory("$mypath");
		$dirname  = dirname($0);
    }


# The process for fixing the files themselves by opening each file and doign the substitutions.
sub ScanDirectory {
	my ($workdir) = shift; 
	my ($startdir) = &cwd; # keep track of where we began
	chdir($workdir) or die "Unable to enter dir $workdir:$!\n";
	opendir(DIR, ".") or die "Unable to open $workdir:$!\n";
	my @names = readdir(DIR) or die "Unable to read $workdir:$!\n";
	closedir(DIR);

	foreach my $name (@names){
		next if ($name eq "."); 
		next if ($name eq "..");
		for ($name) {
			if (m/\.opf/ || m/\.ncx/ || m/\.smil/) {
				print "found $workdir/$name\n"; # tell us what files we are working in.
				$moddate = strftime('%Y-%m-%d',localtime); #get todays date for the modification date.
				open (IN, "+<$workdir/$name");
				@file = <IN>;
				seek IN,0,0;
				foreach $file (@file){
					$file =~ s/\.3gp/.mp3/g;
					$file =~ s/audio\/3gpp/audio\/mp3/g;
					$file =~ s/content="3gpp"/content="mp3"/g;
					$file =~ s/meta name="dtb:revisionDate" content=".*"\/>/meta name="dtb:revisionDate" content="$moddate"\/>/g;
					print IN $file;
				}
				close IN;
				next;
			}



			if (m/\.3gp/) {
				#convert audio here.
				print "Convert $name to WAV audio.\n";
				($file,$dir,$ext) = fileparse($name, qr/\.[^.]*/);
				$newname = $file.".wav";
				
				#edit the line below for the path of the decoder program. default is C:\decode
				$decoderesult = `$decoder -mono -limiter -if $workdir/$name -of $workdir/$newname`;
				
				print $decoderesult;
				#remove 3gp audio after converson.
				unlink "$workdir/$name" or warn "Could not unlink $file: $!";
				print "Convert $newname to MP3 audio.\n";
				($file,$dir,$ext) = fileparse($newname, qr/\.[^.]*/);
				$mp3name = $file.".mp3";
				
				#edit the line below for the path of the lame encoder program. default is C:\lame
				$lameresult = `$lame -b 48 -h $workdir/$newname $workdir/$mp3name`;
				
				print $lameresult;
				#remove wav audio after converson.
				unlink "$workdir/$newname" or warn "Could not unlink $file: $!";
			}

			
		}
	}
}