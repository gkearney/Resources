#!/usr/bin/perl
use XML::Simple;
chomp($nccfile=@ARGV[0]);
#$nccfile = "/Volumes/DAISY_MASTER/ABWA/Jonah_PG3678/ncc.html";

open FILE, "$nccfile" or die $!; #open the ncc.html file

$find = "dc:|ncc:|dtb:|nls:"; #find only the lines with the meta data we need.
@line = <FILE>;
close FILE;

#loop through the file finding only lines with the meta data
for (@line) {
    if ($_ =~ /$find/) {
        $xml .= $_;
    }
}

if ($xml =~ m/<\/head>/gi) {
	$xml_head = "<head>\n$xml"; #put head tags around it for XML::Simple
} else {
	$xml_head = "<head>\n$xml</head>"; #put head tags around it for XML::Simple
}




#build the hash $ref key on the meta data name
$ref = XMLin($xml_head,ForceArray => 0, KeyAttr => 'name');


#Map the meta data into variables for the MARC record
$title = $ref->{meta}->{'dc:title'}->{content};

if (!$title) {
	$title = $ref->{'dc:Title'};
}


$creator = $ref->{meta}->{'dc:creator'}->{content};
if (!$creator) {
	$creator = $ref->{'dc:Creator'}->{content};
}
if (!$creator) {
	$creator = $ref->{'dc:Creator'};
}

$date = $ref->{meta}->{'dc:date'}->{content};
if (!$date) {
	$date = $ref->{'dtb:producedDate'}->{content};
}

$format = $ref->{meta}->{'dc:format'}->{content};
if (!$format) {
	$format = $ref->{'dc:Format'};
}

$uid = $ref->{meta}->{'dc:identifier'}->{content};
if (!$uid) {
	$uid = $ref->{'dc:Identifier'}->{content};
}

$language = $ref->{meta}->{'dc:language'}->{content};
if (!$language) {
	$language = $ref->{'dc:Language'};
}

$publisher = $ref->{meta}->{'dc:publisher'}->{content};
if (!$publisher) {
	$publisher = $ref->{'dc:Publisher'};
}

$totaltime = $ref->{meta}->{'ncc:totalTime'}->{content};
if (!$totaltime) {
	$totaltime = $ref->{meta}->{'dtb:totalTime'}->{content};
}

$subject = $ref->{meta}->{'dc:subject'}->{content};
if (!$subject) {
	$subject = $ref->{'dc:Subject'};
}

$sourcepublisher = $ref->{meta}->{'ncc:SourcePublisher'}->{content};
if (!$sourcepublisher) {
	$sourcepublisher = $ref->{meta}->{'dtb:sourcePublisher'}->{content};
}

$narrator = $ref->{meta}->{'ncc:narrator'}->{content};
if (!$narrator) {
	$narrator = $ref->{meta}->{'dtb:narrator'}->{content};
}

$sourcedate = $ref->{meta}->{'ncc:SourceDate'}->{content};
if (!$sourcedate) {
	$sourcedate = $ref->{meta}->{'dtb:sourceDate'}->{content};
}

$isbn = $ref->{meta}->{'dc:source'}->{content};
if (!$source) {
	$source = $ref->{'dc:Source'};
}

$totaltime =~ s/://gi;
$totaltime = sprintf "%.0f", $totaltime;
if (length $totaltime == 5) {
	$totaltime = "0$totaltime";
	
}

print "Title: $title\nCreator: $creator\nPlaying Time: $totaltime\nNarrator: $narrator\nPublisher: $publisher\nLanguage: $language";

