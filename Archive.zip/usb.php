#!/usr/bin/php -q
<?php 
date_default_timezone_set("Australia/Perth");
$info = `/Resources/usbserial_db.pl`;
$infoarray = explode (",", $info);
#$userid = $infoarray[0];
$driveid = $infoarray[0];

if ($driveid) {

$naw =date('Ymd');
$downloadpath = `defaults read  com.apple.Safari DownloadsPath`;

//`say "$userid $downloadpath"`;

$server = "Bookserver-mac";
$db_name = "DB_library_users";
$table_name = "t_users";
$connection = @mysql_connect("$server","greg","cucat") or die("Couldn't Connect.");
$db = @mysql_select_db($db_name, $connection) or die("Couldn't select database.");


$sql = "SELECT * FROM $table_name WHERE drive_ids LIKE '%$driveid%'";
echo $sql;
$total_result = @mysql_query($sql, $connection) or die("Error #". mysql_errno() . ": " . mysql_error());

while ($row = mysql_fetch_array($total_result)) {
	$uid = $row['uid'];
	$password = $row['password'];
	$last_name = addslashes($row['last_name']);
	$first_name = addslashes($row['first_name']);
	$address = addslashes($row['address']);
	$city = addslashes($row['city']);
	$state = $row['state'];
	$postal_code = $row['postal_code'];
	$country = $row['country'];
	$phone_home = $row['phone_home'];
	$phone_work = $row['phone_work'];
	$phone_mobile = $row['phone_mobile'];
	$email = $row['email'];
	$s_content = $row['s_content'];
	$v_content = $row['v_content'];
	$male_narrator = $row['male_narrator'];
	$female_narrator = $row['female_narrator'];
	$tts_narrator = $row['tts_narrator'];
	$profile = addslashes($row['profile']);
	$drive_ids = $row['drive_ids'];
	$user_class = $row['user_class'];
	$active = $row['active'];
	
}
$username = "$first_name $last_name";
`say "Hello the user is: $username. user ID is: $uid. The drive ID is: $driveid."`;

// using ldap bind anonymously
//  LDAP variables
// $ldaphost = "bookserver-mac";  // your ldap servers
// $ldapport = 389;                 // your ldap server's port number
// 
//  Connecting to LDAP
// 
// $ldapconn = ldap_connect($ldaphost, $ldapport)  or die("Could not connect to $ldaphost");
// ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
// 
// if ($ldapconn) {
// 
//     // binding anonymously
//     $ldapbind = ldap_bind($ldapconn);
// 
//     if ($ldapbind) {
//         echo "LDAP bind anonymous successful...";
//         //$result = ldap_search($ldapconn,"cn=users,dc=bookserver-mac,dc=local", "(uidNumber=$userid)") or die ("Error in search query");
//         $result = ldap_search($ldapconn,"cn=users,dc=bookserver-mac,dc=local", "(description=*$driveid*)") or die ("Error in search query");
// 
// 		$info = ldap_get_entries($ldapconn, $result);
// 		echo $info["count"];
// 		// iterate over array and print data for each entry
// 		for ($i=0; $i<$info["count"]; $i++) 
// 		{
// 			echo "dn is: ". $info[$i]["dn"] ."\n";
// 			$userid  = $info[$i]["uidnumber"][0];
// 			$username =  $info[$i]["cn"][0];
// 			$uid = $info[$i]["uid"][0];
// 			//print_r($info[$i]);
// 			
// 		}
//         
//         
//         
//         
//     } else {
//         echo "LDAP bind anonymous failed...";
//     }
// 
// }
// 
// 
// ldap_unbind ($ldapconn);






//$myresults = `Diskutil eraseDisk MS-DOS "" disk3`;
//print  $myresults;
}
?>