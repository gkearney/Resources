#!/usr/bin/perl

BEGIN {
        push @INC,"/opt/local/lib/perl5/site_perl/5.8.8/";
		push @INC,"/opt/local/lib/perl5/site_perl/5.8.9/";
}

use LWP::Simple;
#use DBI;
use File::Basename;
use Cwd;
use Text::CSV;

@mon = qw/null January February March April May June July August September October November December/;

my ($sec,$min,$hour,$mday,$month,$year,$wday,$yday,$isdst) = localtime(time);
if(length($hour) == 1) {
		$hour = "0" . $hour;
	}
	if(length($min) == 1) {
		$min = "0" . $min;
	}
	if(length($sec) == 1) {
		$sec = "0" . $sec;
	}

	# Set to 2 digit month from 01 to 12
	$month += 1;
	if(length($month) == 1) {
  		$month = "0" . $month;
	}
	# Set to 2 digit day
	if(length($mday) == 1) {
		$mday = "0" . $mday;
	}
	# Use four digit year ($year is a value based on # of years since 1900)
	$year += 1900;
	
$now = "$year-$month-$mday";


my $url = 'ftp://ftp2.bom.gov.au/anon/gen/fwo/IDA00006.dat';
my $file = 'data.csv';

getstore($url, $file);
`perl -pi -e "s/#/,/gi" $file`;







    my $csv = Text::CSV->new();

    open (CSV, "<", $file) or die $!;

    while (<CSV>) {
        if ($csv->parse($_)) {
            my @columns = $csv->fields();
            $location = @columns[1];
			$max_0 = @columns[7];
			$max_1 = @columns[9];
			$forecast_0 = @columns[22];
			$forecast_1 = @columns[23];
			$forecast_date = @columns[3];
			$forecast_date =~ s/..(..)(..)(..)/$3-$mon[$2]-20$1/;
			
			if ($forecast_1 ne '' and $max_1 ne '') {
				$statement = "<p>The forecast for today is: $forecast_0 With a high temperature of $max_0</p>\n<p>The forecast for tomorrow is: $forecast_1 With a high temperature of $max_1</p>"
			} else {
				$statement = "<p>The forecast for today is: $forecast_0 With a high of $max_0</p>\n";
			}
			if ($location ne 'location'){
			$strings .= "
			<level1>
				<h1>$location</h1>
				$statement
			</level1>";
			}
			
        } else {
            my $err = $csv->error_input;
            print "Failed to parse line: $err";
        }
    }
    close CSV;

## Connect to the database, (the directory containing our csv file(s))
#
#    my $dbh = DBI->connect("DBI:CSV:f_dir=.;csv_eol=\n;");
#
#    # Associate our csv file with the table name 'prospects'
#
#    $dbh->{'csv_tables'}->{'weather'} = { 'file' => 'data.csv'};
#
#    # Output the name and contact field from each row
#
#    my $sth = $dbh->prepare("SELECT * FROM weather WHERE location LIKE 'Perth'");
#    $sth->execute();
#    while (my $row = $sth->fetchrow_hashref) {
#        $location = $row->{'location'};
#		$state = $row->{'state'};
#		$forecast_date = $row->{'forecast_date'};
#		$forecast_date =~ s/..(..)(..)(..)/$3-$mon[$2]-20$1/;
#		$issue_date = $row->{'issue_date'};
#		$issue_date =~ s/..(..)(..)(..)/$3-$mon[$2]-20$1/;
#		$issue_time = $row->{'issue_time'};
#		$min_0 = $row->{'min_0'};
#		$max_0 = $row->{'max_0'};
#		$min_1 = $row->{'min_1'};
#		$max_1 = $row->{'max_1'};
#		$min_2 = $row->{'min_2'};
#		$max_2 = $row->{'max_2'};
#		$min_3 = $row->{'min_3'};
#		$max_3 = $row->{'max_3'};
#		$min_4 = $row->{'min_4'};
#		$max_4 = $row->{'max_4'};
#		$min_5 = $row->{'min_5'};
#		$max_5 = $row->{'max_5'};
#		$min_6 = $row->{'min_6'};
#		$max_6 = $row->{'max_6'};
#		$forecast_0 = $row->{'forecast_0'};
#		$forecast_1 = $row->{'forecast_1'};
#		$forecast_2 = $row->{'forecast_2'};
#		$forecast_3 = $row->{'forecast_3'};
#		$forecast_4 = $row->{'forecast_4'};
#		$forecast_5 = $row->{'forecast_5'};
#		$forecast_6 = $row->{'forecast_6'};
#		$forecast_7 = $row->{'forecast_7'};
#    }
#    $sth->finish();

$dtb = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>

        
        
<!DOCTYPE dtbook
          PUBLIC \"-//NISO//DTD dtbook 2005-3//EN\" 
          \"http://www.daisy.org/z3986/2005/dtbook-2005-3.dtd\">

                
                <dtbook xmlns=\"http://www.daisy.org/z3986/2005/dtbook/\" version=\"2005-3\" xml:lang=\"en-AU\">
   <head>
      <meta name=\"dc:Identifier\" content=\"auvpabw-perth-weather\"/>
      <meta name=\"dc:Language\" content=\"en-AU\"/>
      <meta name=\"dc:Title\" content=\"Western Australia forecasts for $forecast_date\"/>
      <meta name=\"dc:Subject\" content=\"Weather --Australia\"/>
      <meta name=\"dc:Creator\" content=\"Bureau of Meteorology\"/>
      <meta name=\"dc:Publisher\" content=\"Assocation for the Blind of Western Australia\"/>
      <meta name=\"dtb:producer\" content=\"Greg Kearney\"/>
      <meta name=\"dc:Date\" content=\"$now\"/>
      <meta name=\"dc:Type\" content=\"Text\"/>
      <meta name=\"dc:Format\" content=\"ANSI/NISO Z39.86-2005\"/>
      <meta name=\"dtb:uid\" content=\"auvpabw-perth-weather\"/>
      <meta name=\"dtb:revision\" content=\"2\"/>
      <meta name=\"dtb:revisionDate\" content=\"$now\"/>
      <meta name=\"Generator\" content=\"odt2daisy by Vincent Spiewak\"/>
   </head>
   <book>
      <frontmatter>
         <doctitle>Western Australia Weather for $forecast_date</doctitle>
         <docauthor>Bureau of Meteorology</docauthor>
      </frontmatter>
      <bodymatter>
$strings
 </bodymatter>
   </book>
</dtbook>
";
#print $dtb;
open(DTB, ">perth_WX.xml");
print DTB $dtb;
close DTB;


$dir = getcwd;


$pipeline_cmd = "$dir/pipeline/pipeline.sh  $dir/pipeline/scripts/create_distribute/dtb/Narrator-DtbookToDaisy.taskScript --input=$dir/perth_WX.xml --outputPath=$dir/WX/";
print "Producing Book\n";
`$pipeline_cmd`;
print "Finished production\n$pipeline_cmd\n\n";

