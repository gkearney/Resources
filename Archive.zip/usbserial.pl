#!/usr/bin/perl

use DBI;
use Device::USB;
use Net::LDAP;
use Mac::Pasteboard; #Mac only we need to find the equivalent for Windows and Linux
#use USB.pm;

$VENDOR = "0x058F";
$PRODUCT = "0x221B";


$VENDOR = "1423";
$PRODUCT = "8731";



    my $usb = Device::USB->new();
    my $dev = $usb->find_device( $VENDOR, $PRODUCT );

   	#printf "Device:\n", $dev->idVendor(), $dev->idProduct();
    $dev->open();
    $usbserial =  $dev->serial_number();
    `say $usbserial`;
  	pbcopy ("$usbserial"); #Mac only :(


   
   $ldap = Net::LDAP->new( 'bookserver-mac' ) or die "$@";

 $mesg = $ldap->bind ;    # an anonymous bind

 $mesg = $ldap->search( # perform a search
                        base   => "cn=users,dc=bookserver-mac,dc=local",
                        filter => "(&(apple-keyword=$usbserial))"
                      );

 $mesg->code && die $mesg->error;

 foreach $entry ($mesg->entries) { 
 
 print $entry->dump; 
 $userdata =  $entry->get_value ( 'sn' ) . " " . $entry->get_value ( 'givenName' );
 #print $ref;
 `say "This drive belongs to $userdata"`;
 
 
 }

 $mesg = $ldap->unbind;   # take down session

    #$dev->set_configuration( $CFG );
    #$dev->control_msg( @params );
    