#!/usr/bin/perl

use Cwd; # module for finding the current working directory
use File::Copy;
use File::Basename;
$mypath = "/Volumes/DaisyMasters/ABWA";

&ScanDirectory("$mypath");


sub ScanDirectory{
	$dirname  = dirname($0);
    my ($workdir) = shift; 

    my ($startdir) = &cwd; # keep track of where we began

    chdir($workdir) or die "Unable to enter dir $workdir:$!\n";
    opendir(DIR, ".") or die "Unable to open $workdir:$!\n";
    my @names = readdir(DIR) or die "Unable to read $workdir:$!\n";
    closedir(DIR);
    
    
    foreach my $name (@names){
        next if ($name eq "."); 
        next if ($name eq "..");
        
        if (-d "$workdir/$name") {  
            # is this a directory?
            
            $cmd = "rm $workdir/$name/AutoRun.exe; $workdir/$name/autorun.inf";
        		print "$cmd\n";
        		`$cmd`;
        		
        		}
        	}
        }