#!/usr/bin/perl

use App::Tweet;
App::Tweet->run( message => 'tell this to twitter', [ username => 'AssocBlindWA', password => ',abwa!' ] );