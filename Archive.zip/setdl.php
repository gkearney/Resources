#!/usr/bin/php -q
<?php 
date_default_timezone_set("Australia/Perth");
$drives = `ls /Volumes`;
$drives = explode("\n",$drives);

$downloadpath = `defaults read  com.apple.Safari DownloadsPath`;

foreach ($drives as &$value) {
    if ($value != 'kiosk') { echo $value; }
}

?>