use DBI;

my $db = 'DB_library';
my $host = 'bookserver-mac';
my $user = 'greg';
my $pass = 'cucat';

#DBI->trace(1);
print "HERE\n";

$dbh = DBI->connect("DBI:mysql:database=$db;host=$host;port=3306",$user, $pass);

# PREPARE THE QUERY
$query = "SELECT b.title, b.`author` ,  bf.bibid, bfd.`field_data` FROM `biblio_field_data` bfd,`biblio_field` bf, `biblio` b 
WHERE ( bf.`tag`=035 AND bf.`subfield_cd`='a')
AND bfd.field_data = 'D7796'
AND bf.`fieldid`=bfd.`fieldid` 
AND b.`bibid`=bf.bibid";

$query_handle = $dbh->prepare($query);

# EXECUTE THE QUERY
$query_handle->execute();

# BIND TABLE COLUMNS TO VARIABLES
$query_handle->bind_columns(undef, \$title, \$author, \$bibid, \$field_data);

# LOOP THROUGH RESULTS
while($query_handle->fetch()) {
	
	
	
   #print "$title $author $bibid\n";
} 


$query = "SELECT CONCAT(bf.`tag`, bf.`subfield_cd`) AS 'tag' , bfd.`field_data` AS 'data' 
FROM `biblio_field` bf, `biblio_field_data` bfd 
WHERE bf.`fieldid`=bfd.`fieldid`AND bf.bibid = $bibid;";

$query_handle = $dbh->prepare($query);

# EXECUTE THE QUERY
$query_handle->execute();

# BIND TABLE COLUMNS TO VARIABLES
$query_handle->bind_columns(undef, \$tag, \$data);
undef ($Synopsis);
undef ($isbn);
undef ($format);
undef ($language);
undef ($agelevel);
undef ($language);
undef ($wipo_test);
undef ($publisher);
undef ($public_note);
# LOOP THROUGH RESULTS
while($query_handle->fetch()) {
	if ($tag eq '520a') {
		$Synopsis = $data;
	}
	
	if ($tag eq '020a') {
			$isbn_marc = $data;
		} else {
			$isbn_marc = "##########";
		}
	
	if ($tag eq '300a') {
			$format = $data;
		} else {
			$format = "Daisy 2.02 audio";
		}
		
	if ($tag eq '041a') {
			$language = $data;
		} else {
			$language = "eng";
		}
	if ($tag eq '041a') {
			$agelevel = $data;
	} else {
		$agelevel = "Adult";
	}
	if ($tag eq '599t') {
						$wipo_test = "$data";
					}
					if ($wipo_test eq '') {
						$wipo_test = "N";
					}
	if ($tag eq '534c') {
							$publisher = "$data";
							$public_note = "";
						}
						if ($publisher eq '' or $the_dir eq "pd") {
							$publisher = "Association for the Blind of Western Australia";
							$public_note = "Public domanin work published by ABWA";
						}
}

print "$Synopsis\n";
print "$isbn\n";
print "$format\n";
print "$language\n";
print "$agelevel\n";
print "WIPO: $wipo_test\n";
print "$publisher\n";
print "$public_note\n";

$query_handle->finish();
$dbh->disconnect();

if ($the_dir eq "pd" or $wipo_test eq "Y"){
	print "We sent the book to WIPO\n";
} else {
	print "We DO NOT send the book to WIPO\n";
}

print "DONE\n";