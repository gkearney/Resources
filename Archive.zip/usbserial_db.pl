#!/usr/bin/perl

use DBI;
use Device::USB;
use Net::LDAP;
use Mac::Pasteboard; #Mac only we need to find the equivalent for Windows and Linux
#use USB.pm;

$VENDOR = "1423";
$PRODUCT = "8731";



    my $usb = Device::USB->new();
    my $dev = $usb->find_device( $VENDOR, $PRODUCT );

   	#printf "Device:\n", $dev->idVendor(), $dev->idProduct();
    $dev->open();
    $usbserial =  $dev->serial_number();
    #`say $usbserial`;
  	pbcopy ("$usbserial"); #Mac only :(


$db ="DB_library_users";
## mysql database user name
$user = "selectonly";
## mysql user database name 
## mysql database password
$pass = "abwa";
## user hostname : This should be "localhost" but it can be diffrent too
$host="bookserver-mac";
## SQL query


$dbh = DBI->connect("DBI:mysql:$db:$host", $user, $pass);


$tmptable_sql = "CREATE TEMPORARY TABLE theSubjects (the_subject VARCHAR(50) NOT NULL)";
$sqlQuery  = $dbh->prepare($tmptable_sql)
or die "Can't prepare $query: $dbh->errstr\n";
 
$rv = $sqlQuery->execute
or die "can't execute the query: $sqlQuery->errstr";




$query = "select last_name, first_name, uid from t_users where drive_ids LIKE '%$usbserial%'";
#print "$query\n";

$sqlQuery  = $dbh->prepare($query)
or die "Can't prepare $query: $dbh->errstr\n";
 
$rv = $sqlQuery->execute
or die "can't execute the query: $sqlQuery->errstr";


while(($last_name, $first_name, $uid) = $sqlQuery->fetchrow_array()) { 
 	#print "$first_name $last_name $uid\n";
 	$uid2 = $uid;
 	
 
 	$query_subject = "select user_subject from t_user_subject where uid = '$uid';";

	$sqlQuery_subject  = $dbh->prepare($query_subject)
	or die "Can't prepare $query: $dbh->errstr\n";
 
	$rv = $sqlQuery_subject->execute
	or die "can't execute the query: $sqlQuery->errstr";

	while(($subject) = $sqlQuery_subject->fetchrow_array()) {
		$user_subjects = "$subject";
 		
 		
 		 
	}
	
	
 
 	#`say "This drive belongs to $userdata $uidNumber"`; 
}


`say $usbserial`;
print $usbserial;




$rc = $sqlQuery->finish;



# find the books that match the subjects.
# $db ="DB_library";
# # mysql database user name
# $user = "selectonly";
# # mysql user database name 
# # mysql database password
# $pass = "abwa";
# # user hostname : This should be "localhost" but it can be diffrent too
# $host="bookserver-mac";
# # SQL query
# $dbh = DBI->connect("DBI:mysql:$db:$host", $user, $pass);
# 
# $query_books = "select title from biblio where topic1 LIKE '$user_subjects'";
# print $query_books;
# 	$sqlQuery  = $dbh->prepare($query_books)
# 	or die "Can't prepare $query: $dbh->errstr\n";
#  
# 	$rv = $sqlQuery->execute
# 	or die "can't execute the query: $sqlQuery->errstr";
# 
# 	while(($title) = $sqlQuery->fetchrow_array()) { 
#  		
#  		print $title;
#  		#`say "This drive belongs to $userdata $uidNumber"`; 
# 	}
# 
# 
# 
# 
# 
# 
# $rc = $sqlQuery->finish;

 