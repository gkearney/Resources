#!/usr/bin/perl

BEGIN {
        push @INC,"/opt/local/lib/perl5/site_perl/5.8.8/";
}
use Net::FTP;

$zipfile = $ARGV[0];

# Sending the zip file to WIPO TIGAR
		$host = "tigarftp.wipo.int";
		$user = "ABWA-upd";
		$password = "-069-bm056df";
		
		$f = Net::FTP->new($host) or die "Can't open $host\n";
		$f->login($user, $password) or die "Can't log $user in\n";
		
		$dir = "/";

		$f->cwd($dir) or die "Can't cwd to $dir\n";
		
		$f->binary();
		$file_to_put = "$zipfile";
		print "Sending $zipfile to WIPO TIGAR\n\n";
		$f->put($file_to_put) or die "Can't put $file_to_put into $dir\n";

		print "Finished sending $zipfile to WIPO TIGAR\n\n";