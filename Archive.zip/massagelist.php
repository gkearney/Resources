#!/usr/bin/php
<?php 
$to = "Kathleen.Grizzelle@guidedogswa.com.au,Barbara.Brockbank@guidedogswa.com.au,gkearney@gmail.com";
$to = "gkearney@gmail.com";
$email = "tamara@gatetoserentiy.com";

$message = "This is a reminder that Tamara Kearney has massage appointments open today and Friday. You can ring Tamara on 0410 697 502 for an appointment";

$subject = "Massage appointment available";
$headers = "From: $email" . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
    


mail($to, $subject, $message, $headers);



?>

